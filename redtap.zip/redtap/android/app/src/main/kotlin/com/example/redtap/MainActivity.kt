package com.example.redtap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
